#ifndef __display_H__
#define __display_H__

void display(void);
void display_code(void);

#endif