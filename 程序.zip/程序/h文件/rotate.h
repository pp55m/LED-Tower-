#ifndef __rotate_H__
#define __rotate_H__

void rotate1(void);
void rotate2(void);

#endif