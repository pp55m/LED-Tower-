#ifndef __rangfall_H__
#define __rangfall_H__

void rangfall1(void);

#endif