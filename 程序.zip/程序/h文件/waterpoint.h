#ifndef __waterpoint_H__
#define __waterpoint_H__

void waterpoint(void);

#endif