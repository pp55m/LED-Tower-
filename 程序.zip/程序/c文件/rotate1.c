#include "main.h"	

void rotate1(void)
{
	u16 dat=0xfffe,time=800;
	u8 i,rankl,rankh,breaktime;
	P0=0xff;
	P1=0xff;
	P3=0xff;
	rankl=(u8)dat;
	P2=rankl;
	delay_ms(time);
	for(i=0;i<=10;i++)	//���٣����ݣ��׶�	#��ͷ
	{
		dat=_irol_(dat,1);
		time=time-40;
		if(i==4)
			dat=0xffde;
		else if(i==10)
			dat=0xf7de;
		rankl=(u8)dat;
		rankh=(u8)(dat>>8);
		P2=rankl;
		P3=rankh;
		delay_ms(time);
	}
	for(i=0;i<=15;i++)	//���ټ���
	{
		dat=_irol_(dat,1);
		time=time-17;
		rankl=(u8)dat;
		rankh=(u8)(dat>>8);
		P2=rankl;
		P3=rankh;
		delay_ms(time);
	}

	breaktime=6;//תȦ����
	while(breaktime)
	{
	for(i=0;i<=15;i++)	//���ٽ׶�
	{
		dat=_irol_(dat,1);
		rankl=(u8)dat;
		rankh=(u8)(dat>>8);
		P2=rankl;
		P3=rankh;
		delay_ms(time);
	}
	breaktime--;
	}

	for(i=0;i<=15;i++)	//��������
	{
		dat=_irol_(dat,1);
		time=time+17;
		rankl=(u8)dat;
		rankh=(u8)(dat>>8);
		P2=rankl;
		P3=rankh;
		delay_ms(time);
	}
	for(i=0;i<=14;i++)	//�����ٽ׶�
	{
		dat=_irol_(dat,1);
		time=time+30;
		if(i==4)
			dat=0xfbdf;
		else if(i==10)
			dat=0xf7ff;
		rankl=(u8)dat;
		rankh=(u8)(dat>>8);
		P2=rankl;
		P3=rankh;
		delay_ms(time);
	}
	P3=0xff;//��ȫ��
	delay_ms(1300);
}
/*
16λ���ձ�
8 4 2 1 8 4 2 1//8 4 2 1 8 4 2 1
  -f-     -f-       -f-        e		״̬1
  -f-	  -f-		 b		   e		״̬2
  -f-   7            d		   e		״̬3
  //����
  -f-   7            d         e
  //���٣�������
  -f-     b          d      -f-			״̬4
  -f-     b         -f-		-f-			״̬5
  //����

*/
/*��������
//��֪��Ϊʲôcrol�ò��� ��P2=_crol_(P2,1);	�޷����� ����//�������ĵط����ۿ�����ѭ��
void rotate(void)
{
	u8 i,breaktime;
	u16 time=600; //��ʱʱ��
	P0=0xff;
	P1=0xff;
	P2=0xfe;
	P3=0xff;
	delay_ms(time);
//<
	P2 =0xfd;
	time=time-50;  //��ת�ٶȼӿ�
	delay_ms(time);
	P2 =0xfb;
	time=time-50;  //��ת�ٶȼӿ�
	delay_ms(time);
	P2 =0xf7;
	time=time-50;  //��ת�ٶȼӿ�
	delay_ms(time);
	P2 =0xef;
	time=time-50;  //��ת�ٶȼӿ�
	delay_ms(time);
	P2 =0xdf;
	time=time-50;  //��ת�ٶȼӿ�
	delay_ms(time);
//>
	P2=0xbe;
	P3=0xff;
	time=time-50;
	delay_ms(time);
	P2=0x7d;
	time=time-50;
	delay_ms(time);
	P2=0xfb;
	P3=0xfe;
	time=time-50;
	delay_ms(time);
//<
	P2=0xf7;
	P3=0xfd;
	time=time-40;
	delay_ms(time);
	P2=0xef;
	P3=0xfb;
	time=time-30;
	delay_ms(time);
//>
	P2=0xde;
	P3=0xf7;
	time=time-20;
    delay_ms(time);
	breaktime=10;
	while(breaktime)//ֹͣ���٣�������ת
	{
	 	P2=0xbd;
		P3=0xef;
		delay_ms(time);	
		P2=0x7b;
		P3=0xdf;
		delay_ms(time);	
		P2=0xf7;
		P3=0xbe;
		delay_ms(time);	
		P2=0xef;
		P3=0x7d;
		delay_ms(time);	
		P2=0xde;
		P3=0xf7;
		delay_ms(time);	
		breaktime--;
	}
//<		   //��ʼ����
		P2=0xbd;
		P3=0xef;
		time=time+20;
		delay_ms(time);
		P2=0x7b;
		P3=0xdf;
		time=time+30;
		delay_ms(time);
//>
	P2=0xf7;
	P3=0xbe;
	time=time+40;
	delay_ms(time);
	P2=0xef;
	P3=0x7d;
	time=time+30;
	delay_ms(time);
	P2=0xdf;
	P3=0xfb;
	time=time+30;
	delay_ms(time);
	P2=0xbf;
	P3=0xf7;
//<
	P2=0x7f;
	P3=0xef;
	time=time+30;
	delay_ms(time);
	P2=0xff;
	P3=0xde;
	time=time+30;
	delay_ms(time);
	P3=0xbd;
	time=time+30;
	delay_ms(time);
//>
	P3=0x7b;
	time=time+30;
	delay_ms(time);
	P3=0xf7;
	time=time+30;
	delay_ms(time);
	P3=0xef;
	time=time+30;
	delay_ms(time);
//<
	P3=0xdf;
	time=time+30;
	delay_ms(time);
	P3=0xbf;
	time=time+30;
	delay_ms(time);
	P3=0x7f;
	time=time+30;
	delay_ms(time);
//>
	P3=0xff;
}
*/