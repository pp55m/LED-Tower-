#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC89C5xRC.H>
#include"INTRINS.H"	//������λҪ��
#define MAIN_Fosc	11059200UL		//�궨����ʱ��HZ

typedef unsigned char u8;
typedef unsigned int u16;

sbit row1=P0^0;
sbit row2=P0^1;
sbit row3=P0^2;
sbit row4=P0^3;
sbit row5=P0^4;
sbit row6=P0^5;
sbit row7=P0^6;
sbit row8=P0^7;
sbit row9=P1^0;
sbit row10=P1^1;
sbit row11=P1^2;
sbit row12=P1^3;
sbit row13=P1^4;
sbit row14=P1^5;
sbit row15=P1^6;
sbit row16=P1^7;

sbit rank1=P2^0;
sbit rank2=P2^1;
sbit rank3=P2^2;
sbit rank4=P2^3;
sbit rank5=P2^4;
sbit rank6=P2^5;
sbit rank7=P2^6;
sbit rank8=P2^7;
sbit rank9=P3^0;
sbit rank10=P3^1;
sbit rank11=P3^2;
sbit rank12=P3^3;
sbit rank13=P3^4;
sbit rank14=P3^5;
sbit rank15=P3^6;
sbit rank16=P3^7;

void delay_ms(u16 );
void delay_10us(u16 us);
u8 uc_change (u8 dat);//u8�������ݾ��񽻻�

#endif